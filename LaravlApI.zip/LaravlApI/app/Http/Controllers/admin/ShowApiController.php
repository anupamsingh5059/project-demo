<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Http;



class ShowApiController extends Controller
{
    

    public function show(){



          //$usrl = 'https://api.covidtracking.com/';

        $datauser  = 'https://socket.downloadskkily.com/v1/getCounters';

             //$response =  Http::get($usrl);
        $response =  Http::get($datauser);

               
              //$data = ($response->body());

               
                //  print_r($data);
                // die();

             $data = json_decode($response->body());
                  echo "<pre>";
//     foreach($data as $res)
//     {
     
//          $result = (array)$res;
         
               
//                  print_r($result);
             
         

//     }
             
      
         //die(); 

       //endforeach
          
            return view("admin.index", compact('data'));
    }




    public function Dashboard()
    {



       



     

     

     //    $tokendata =   (string)$res->getBody();

     //     dd($tokendata);



          $url =  "http://3.110.62.230:3000/v1/getCounters";
                  
               //      'headers'=>[
               //        "auth" => "token which you received in login responce",
               //    ],


               // $data =  Http::withHearders([

               //      "auth" => "token which you received in login responce",
                    
               //     ])->get( $url->collect());


           return view("admin.dashboard");    
      
       // return view("admin.dashboard", ['resultData'=>$data]);

    }



     public function AdminLogin(Request $request)
     {
           
          
         // $request->post();
              
         //dd($json);

             $email   =   $request->post('email');
           //  dd($email);
              $pass   =   $request->post('password');

    
            //$client = new Client();


           // $http = new GuzzleHttp\Client;


           



              
           $http = new \GuzzleHttp\Client(); 



        $res = $http->request('POST', 'http://3.110.62.230:3000/api/users/login', [

            'headers'=>[

                "Accept"=>"application/json",
                     
                // 'Authorization'=>'Bearer'.
                           // : "token which you received in login responce"
            ],

            'form_params' =>[

                // 'client_id' => 'test_id',
                // 'secret' => 'test_secret',


                'email'=>$email,
                'password'=>$pass,
            ]
        ]);
        // echo $res->getStatusCode();
        // // 200
        // echo $res->getHeader('content-type');
        // // 'application/json; charset=utf8'
        // echo $res->getBody();


     //$data =  json_decode((string)$res->getBody(), true);

        //dd($res);

         //$json = json_decode($res->getBody()); 
        $json = json_decode((string)$res->getBody(), true);






          //dd($json);

           //dd($json['status']);

          //return redirect()->route('dashboard');

         // }catch(\Exception $e){

         //         return redirect()->back()->with('error', 'Login fail Please try again.');
         // }

            



        if($json['status']==true){
           
             return redirect('/dashboard');

    }else{

        // $request->session()->flash('error', 'Please enter Correct Password');
                
        //    return redirect('login');

             // return redirect()->back()->with('error', 'Login fail Please try again.');

           return  redirect('admin')->with('error', 'Login fail Please try again');
        }


     }


    
     public function login()
     {
      
      
          return view("admin.login");

     }





    




    


}

