<?php include_once('header/header.php'); 
include_once('connection/config.php');
$error='';
session_start();
if(isset($_POST['submit']))
{
	$email = $_POST['email'];
    $password = $_POST['pass'];
      
	$query="SELECT * FROM users WHERE email='$email' and  pass='$password' ";

  $result =	mysqli_query($conn,$query);

	// $row=mysqli_fetch_array($result);

	// $count=mysqli_num_rows($result);

	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
$count = mysqli_num_rows($result);  

    if($count==1)
    {

        $_SESSION["Email"]=$row['email'];
		$_SESSION["password"]=$row['pass'];
      // $_SESSION["First_Name"]=$row['username'];
        
        header("Location: registration.php"); 
    }
    else
    {
		//echo '<script>alert("Email Id Already Exists");</script>'; 
		$error = 'please enter Email ';
    }
} 
	
	


?>
   




   


<div style="color:#C23D29;padding: 0 10px 15px 38px;"><?php echo "$error"; ?></div>
<h2>Weekly Coding Challenge #1: Sign in/up Form</h2>
<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form action="#"  method="POST">
			<h1>Create Account</h1>
			<div class="social-container">
				<a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
				<a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
				<a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
			</div>
			<span>or use your email for registration</span>
			<input type="text" placeholder="Name" name="name">
			<input type="email" placeholder="Email" name="email">
			<input type="password" placeholder="Password"  name="pass">
			
			<button><a href=""></a>   Sign Up</button>
		</form>
	</div>
	
	<div class="form-container sign-in-container">
		<form action="#" method="POST" >
			<h1>Sign in</h1>
			<div class="social-container">
				<a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
				<a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
				<a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
			</div>
			<span>or use your account</span>
			<input type="email" placeholder="Email" name="email">
			<input type="password" placeholder="Password" name="pass">
			<a href="#">Forgot your password?</a>
			<!-- <button name="submit">Sign In</button> -->
			<input type="submit" name="submit" class="btn btn-primary" value = "Login"/>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>Welcome Back!</h1>
				<p>To keep connected with us please login with your personal info</p>
				<button class="ghost" id="signIn">Sign In</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>Hello, Friend!</h1>
				<p>Enter your personal details and start journey with us</p>
				<!-- <button class="ghost" id="signUp">    Sign Up</button> -->
				<!-- <a href="registration.php" type="button" class="ghost" id="signUp">Sign Up</a> -->
				<a class="btn btn-primary" target="_blank" href="sign.php">Sign Up</a>

				<!-- <button type="button" class="btn btn-primary"><a href="sign.php"></a>Sign Up</button> -->
			</div>
		</div>
	</div>
</div>

<?php include_once('footer/footer.php');  ?>
