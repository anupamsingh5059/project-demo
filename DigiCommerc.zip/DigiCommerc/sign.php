
<?php


error_reporting(0);
include_once('connection/config.php');
session_start();


?>


<?php include_once('header/header.php');  ?>
<h2>Weekly Coding Challenge #1: Sign in/up Form</h2>

<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form action="#" method="POST">
			<h1>Create Account</h1>
			<div class="social-container">
				<a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
				<a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
				<a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
			</div>
			<span>or use your email for registration</span>
			<input type="text" name="username" placeholder="Name"  required>
			<input type="email" name="email" placeholder="Email"   required>
			<input type="password" name="pass" placeholder="Password"  required>
			
			<button><a href=""></a>Sign Up</button>
		</form>
	</div>
	<div class="form-container sign-in-container">
		<form action="#" method="POST">
			<h1>Sign Up</h1>
			<div class="social-container">
				<a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
				<a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
				<a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
			</div>
			<span>or use your account</span>
            <input type="text" name="username" placeholder="User Name" required >
			<input type="email" name="email" placeholder="Email" required>
			<input type="password" name="pass"  placeholder="Password" required >
			<a href="#">Forgot your password?</a>
			<button name="submit">Sign Up</button>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>Welcome Back!</h1>
				<p>To keep connected with us please login with your personal info</p>
				<button class="ghost" id="signIn">Sign In</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>Hello, Friend!</h1>
				<p>Enter your personal details and start journey with us</p>
				<!-- <button class="ghost" id="signUp">    Sign Up</button> -->
				<!-- <a href="registration.php" type="button" class="ghost" id="signUp">Sign Up</a> -->
				<a class="btn btn-primary" target="_blank" href="login.php">Login</a>

				<!-- <button type="button" class="btn btn-primary"><a href="sign.php"></a>Sign Up</button> -->
			</div>
		</div>
	</div>
</div>

<?php include_once('footer/footer.php');  ?>
<?php
if(isset($_POST))
{

    

  $email = $_POST['email'];


  $sql=mysqli_query($conn,"SELECT * FROM users where email='$email'");
  if(mysqli_num_rows($sql)>0)
  {
     
      echo '<script>alert("Email Id Already Exists");</script>'; 
      exit;
  }elseif($_POST){
    {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $pass = $_POST['pass']; 
        
        $query = "INSERT INTO users(username, email, pass) VALUES (' $username','$email', '$pass' )";
       
      $sql = mysqli_query($conn, $query);
       
 
      if($sql)
        {
        echo '<script>alert("SignUp has been successfully");</script>';
        }else
          {
            echo'<script>alert("SignUp has been not successfully");</script>';
          }
    
      }
  }



}

?>

