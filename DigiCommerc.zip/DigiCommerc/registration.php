<?php


include_once('header/header1.php');

  session_start();
  // if($_SESSION['email_id']==''){
  // echo "<script>window.location.href='login.php'</script>";
  // }
?>

<?php
include_once('connection/config.php');


if(isset($_POST['submit']))
{
  
   $fname = $_POST['fname'];
   $lname = $_POST['lname'];

   $mobile = $_POST['mobile'];
   $email = $_POST['email'];
   $gender = $_POST['gender'];

   $address = $_POST['address'];
   $city = $_POST['city'];
   $state = $_POST['state'];
   $pin = $_POST['pin'];
 

   

   if($fname!='' && $lname!='' && $pin!=''&& $mobile!='' && $email!='' && $gender!=''   && $city!='' && $state!='' && $address!='')
   {

  

  $sql = "INSERT INTO regitration_form (fname, lname, email, mobile, gender, address, city, pin, state) VALUES ('$fname','$lname', '$email', '$mobile','$gender','$address','$city', '$state','$pin')";
 
 $data = mysqli_query($conn, $sql);


  if($data)
    {
    echo '<script>alert("Registration has been successfully");</script>';
    }else
      {
        echo'<script>alert("Registration has been not successfully");</script>';
      }

  }else{

       echo "All filed are Required";
  }
}








?>


<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset="UTF-8">
        <title>Responsive Registaration Form</title>
        <link rel="stylesheet" href="css/sty">
        <script type="text/javascript" lang="javascript" src=""></script>
    </head>
       
    <body>
  
    <div class="container">
  <h3>Student Form List</h3>
  <form action=""  method="POST"  enctype="multipart/form-data">
 First_Name <input type="text" class="form-control" name="fname">
 Last_Name <input type="text" class="form-control" name="lname">
   <!-- Gender <input type="checkbox" class="form-control" name="gender"> -->
 
      Mobile   <input type="mobile" class="form-control" name="mobile">
      Email    <input type="email" class="form-control" name="email">
      <div class="form-group">
  <label for="comment">Address</label>
  <textarea class="form-control" rows="5" id="comment" name="address" value=""></textarea>
</div>   
 
City   <input type="text" class="form-control" name="city">
State   <input type="text" class="form-control" name="state">
PinCode   <input type="number" class="form-control" name="pin">

      <br>
      <!-- <input type="file" class="form-control" name="file"> -->
      <!-- <b> Enter Date of Birth: <input type=date id = DOB name="dob"> </b>  
      <br> -->
      Gender
  <label><input type="checkbox" value="male" name="gender">male </label>
  <label><input type="checkbox" value="females" name="gender">females </label>
  <br>
        <input type="submit" class="btn btn-primary" name="submit">

  </form>
    </body>
</html>




