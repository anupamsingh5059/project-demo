<?php


    


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "digicommerce";


$conn = new mysqli($servername,$username,$password,$dbname);

if(!$conn){

	die("connection faild:". mysqli_connect_error());

}
else{

	//echo("connection successfully");

}

?>