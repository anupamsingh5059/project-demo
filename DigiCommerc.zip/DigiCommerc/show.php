<?php include_once('header/header1.php');

include_once('connection/config.php');
?>
<?php
  if(isset($_GET['student_id']))
  {
    $delete = mysqli_query($conn,"DELETE FROM regitration_form WHERE id='".$_GET['student_id']."'");
    if($delete)
    {
        echo "<script>alert('Student Profile Deted Successfully...!!!');
        window.location.href='show.php';
        </script>";
    }
  }
?>
<div class="container-fluid">
  <h3>Student List</h3>
  <table class=" table table-bordered" >
          <thead style="background: #4a4a75;color: white;font-size: 19px;font-weight: bold;font-style: italic;">
            <tr>
              <th>ID.</th>
              <th> First_Name.</th>
              <th>Last_Name.</th>
              <th>MOBILE.</th>
              <th>EMAIL.</th>
              <th>Gender</th>
              <th>Address</th>
              <th>State</th>
              <th>City</th>
              <th>Pin</th>
              <th>Operations</th>
            </tr>

           </thead >
              <tbody>
        <?php
          $sql = "SELECT * FROM regitration_form";
          $q = mysqli_query($conn,$sql);
            $total = mysqli_num_rows($q);
            
             while ($result=mysqli_fetch_assoc($q))
              {?>
               <tr>
                <td><?=$result['id']?></td>
                <td><?=$result['fname']?></td>
                <td><?=$result['lname']?></td>
                <td><?=$result['mobile']?></td>
                <td><?=$result['email']?></td>
                <td><?=$result['gender']?></td>
                <td><?=$result['address']?></td>
                <td><?=$result['state']?></td>
                <td><?=$result['city']?></td>
                <td><?=$result['pin']?></td>
                <td>
                
                  <a href="update.php?student_id=<?=$result['id']?>" class="btn btn-success">Edit</a>
                 
                  <a href="show.php?student_id=<?=$result['id']?>" class="btn btn-danger" onclick="return confirm('Are you sure to Delete this data..')">Delete</a>
                </td>
               </tr>
              <?php
              }
              ?>
          </tbody>
         </table>
</div>
</body>
</html>