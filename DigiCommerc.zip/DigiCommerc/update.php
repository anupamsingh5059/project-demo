<?php

include_once('connection/config.php');
include_once('header/header1.php');
//error_reporting(0);
  session_start();
  // if($_SESSION['email_id']==''){
  // echo "<script>window.location.href='login.php'</script>";
  // }




    if(isset($_GET['student_id']))
       {

   $getStudent = mysqli_query($conn,"select * from regitration_form where id='".$_GET['student_id']."' ");

          $student = mysqli_fetch_array($getStudent);
        

       }
  

?>

<?php

if(isset($_POST['submit']))

{



   
      $fname = $_POST['fname'];
       $lname = $_POST['lname'];
      $email = $_POST['email'];
      $mobile = $_POST['mobile'];
       $address = $_POST ['address'];
     // $gender = $_POST['gender'];
      $gender = isset($_POST['gender']) ? $_POST['gender'] : ''; 

      $city = $_POST['city'];
      $state= $_POST['state'];
      $pin = $_POST['pin'];



//$sql = mysqli_query($conn, "UPDATE regitration_form SET  fname='".$fname."',  lname ='".$lname."', mobile='".$mobile."', email='".$email."', address='".$address."', gender='".$gender."', state='".$state."', city='".$city."', pin='".$pin."', where id='".$_GET['student_id']."' ");
$sql = " UPDATE regitration_form SET fname='$fname',lname='$lname',email='$email',mobile='$mobile',gender='$gender', address='$address', city='$city', pin='$pin',state='$state' where id='".$_GET['student_id']."' ";

// $sql;
// die();

if(mysqli_query($conn, $sql))
 {
   echo "<script>alert('Record  updated') </script>";
 }


}   

?>


<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta charset="UTF-8">
        <title>Responsive Registaration Form</title>
        <link rel="stylesheet" href="css/sty">
        <script type="text/javascript" lang="javascript" src=""></script>
    </head>
       
    <body>
  
    <div class="container">
  <h3>Student Form List</h3>
  <form action=""  method="POST"  enctype="multipart/form-data">
 First_Name <input type="text" class="form-control" name="fname" value="<?=$student['fname']?>">
 Last_Name <input type="text" class="form-control" name="lname" value="<?=$student['lname']?>">
   <!-- Gender <input type="checkbox" class="form-control" name="gender"> -->
 
      Mobile   <input type="mobile" class="form-control" name="mobile" value="<?=$student['mobile']?>">
      Email    <input type="email" class="form-control" name="email" value="<?=$student['email']?>">
      <div class="form-group">
  <label for="comment">Address</label>
  <textarea class="form-control" rows="5" id="comment" name="address" value=""><?=$student['address']?></textarea>
</div>   
 
City   <input type="text" class="form-control" name="city" value="<?=$student['city']?>">
State   <input type="text" class="form-control" name="state" value="<?=$student['state']?>">
PinCode   <input type="" class="form-control" name="pin" value="<?=$student['pin']?>">

      <br>
      <!-- <input type="file" class="form-control" name="file"> -->
      <!-- <b> Enter Date of Birth: <input type=date id = DOB name="dob"> </b>  
      <br> -->
    
      Gender:
<input type="radio" name="gender"
<?php if (isset($gender) && $gender=="female") echo "checked";?>
value="female">Female
<input type="radio" name="gender"
<?php if (isset($gender) && $gender=="male") echo "checked";?>
value="male">Male
  <br>
        <input type="submit" class="btn btn-primary" name="submit">

  </form>
    </body>
</html>




   





   
