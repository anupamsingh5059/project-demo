<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Model;


use Jenssegers\Mongodb\Eloquent\Model;

class TicketChats extends Model
{
     use HasFactory;

     protected $connection = 'mongodb';

     protected $table = 'tickets_chat';

   //   protected $fillable = [


       
   //      "TicketTransactionId",
   //      "playerId" ,
   //      "desc" ,
   //      "TicketImage" ,
   //      "cd_utc" ,
   //      "PicStatus" ,
   //      "mobile_no",
   //      "pp",
   //      "date",
   //      "time",
   //      "ticketno",
   //      "ticket_status",
   //      "file",
   //      "status",
       



   //   ];

}
