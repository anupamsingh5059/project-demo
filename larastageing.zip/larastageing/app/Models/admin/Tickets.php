<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model;

class Tickets extends Model
{
    protected $connection = 'mongodb';
}
