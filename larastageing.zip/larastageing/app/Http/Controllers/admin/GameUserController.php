<?php



// namespace App\Http\Controllers\Admin;
// use App\Http\Controllers\Controller;

// use App\Models\admin\Game_user;
// use Illuminate\Http\Request;



namespace App\Http\Controllers\admin;
use App\Models\admin\Leader_board;
use App\Models\admin\Game_user;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

use App\Models\admin\Tickets;
use App\Models\admin\TicketChats;
use Carbon\Carbon;


class GameUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
      public function index()
      {


                        $dataUser =  Game_user::all();
           
                return view('admin.index', compact('dataUser'));





        //    function convertMongoIds(array &$array){
           
        //     }

    //     $result = $collection->findOne([
    //         '_id' => new \MongoDB\BSON\ObjectId("")
    //    ]);
       
       
       ///var_dump((string)$result->_id, $result->_id->__toString());








    }
        
    

    public function player()
    {
         

        //$response =  Game_user::all();
        
         //$response['data'] = $Gameuserdata; 


         

       

         //return response()->json($response);
         //return json_encode(array('data'=>$response));


       //return view('admin.player', compact('data'));

    }

    // public function getData(Request $request) {


          
    //     $draw 				= 		$request->get('draw'); // Internal use
    //     $start 				= 		$request->get("start"); // where to start next records for pagination
    //     $rowPerPage 		= 		$request->get("length"); // How many recods needed per page for pagination

    //     $orderArray 	   = 		$request->get('order');
    //     $columnNameArray 	= 		$request->get('columns'); // It will give us columns array
                            
    //     $searchArray 		= 		$request->get('search');
    //     $columnIndex 		= 		$orderArray[0]['column'];  // This will let us know,
    //                                                         // which column index should be sorted 
    //                                                         // 0 = id, 1 = name, 2 = email , 3 = created_at

    //     $columnName 		= 		$columnNameArray[$columnIndex]['data']; // Here we will get column name, 
    //                                                                     // Base on the index we get

    //     $columnSortOrder 	= 		$orderArray[0]['dir']; // This will get us order direction(ASC/DESC)
    //     $searchValue 		= 		$searchArray['value']; // This is search value 


    //     $users = DB::collection('game_users');
    //     $total = $users->count();


       


    //     $totalFilter = DB::collection('game_users');
    //     if (!empty($searchValue)) {
    //         $totalFilter = $totalFilter->where('un','like','%'.$searchValue.'%');
    //         $totalFilter = $totalFilter->orWhere('mobile_no','like','%'.$searchValue.'%');
    //     }
    //    $totalFilter = $totalFilter->count();

       
    //     $arrData = DB::collection('game_users');
    //     $arrData = $arrData->skip($start)->take($rowPerPage);
    //     $arrData = $arrData->orderBy($columnName,$columnSortOrder);

    //     if (!empty($searchValue)) {
            
    //         $arrData = $arrData->where('un','like','%'.$searchValue.'%');
    //         $arrData = $arrData->orWhere('mobile_no','like','%'.$searchValue.'%');
           
    //     }

    // //    $arrData = $arrData->get();

    // //             $array=$arrData;

    // //     $response = array(

    // //          "draw" => intval($draw),
    // //          "recordsTotal" => $total,
    // //          "recordsFiltered" => $totalFilter,
    // //          "data" => $arrData,

    // //     );



    //          $arrData = $arrData->get();

    //                 //$array=$arrData;

    //                 $response = array(
    //                     "draw" => intval($draw),
    //                     "recordsTotal" => $total,
    //                     "recordsFiltered" => $totalFilter,
    //                     //"data" => $arrData.toString('_id'),
    //                     "data" => $arrData,
    //                 );

    //            return response()->json($response);


    // }


// ticket controller







public function Ticket()
{


    //$userData = DB::collection('leader_board');

        $ticket = Tickets::all();
         

   // dd($ticket);
     return view('admin.ticket', compact('ticket'));



}







         public function show($id)
         { 
                 $user = Tickets::find($id);

                 return response()->json($user);


               //return redirect('admin.ticket')->json($user);
         }

         // public function TicketInsert($id)
         // {

         //         $user = Tickets::find($id);

         //         return response()->json($user);


         //       //return redirect('admin.ticket')->json($user);
         // }
  public function Chats_Data(Request $request){

        
//      $request->validate([
          
//        'desc'=>'required',
//        'user_player'=>'required',
//        'mobile_no'=>'required',
// ]);


            $request->validate([

                'user_player' => 'required',
                'desc'=>'required',

                'TicketImage'=>'nullable',
                'cd_utc'=>'nullable',
                'picStatus'=>'nullable',
                'mobile_no' => 'required',
                'pp'=>'nullable',
                'Ddate'=>'nullable',
                'Dtime'=>'nullable',
                'ticket_no'=>'nullable',
                'ticketstatus'=>'nullable',
                
                'file'=>'nullable',
                'stut'=>'nullable',
            
              ]);


             return $request->post;


      $model = new TicketChats();
      $model->desc = $request->post('desc');
      $model->TicketTransactionId = $request->post('user_player');
      $model->mobile_no = $request->post('mobile_no');
     
         $model->save();
      

         return ["msg"=>"Data Inserted Into Database"];

       //  $dataUsermodel =  new  TicketChats();

       //  $dataUsermodel->desc =$request->post('desc');



       //  $dataUsermodel->save();

       //    return ["result"=>"Data inserted"];
  // $tickettt = TicketChats::all();

   //dd($tickettt);
                    
          //return   $request->post();
  // dd($request->all());
  

  
       //  $request->validate([

       //     'user_player' => 'required',
       //     'desc'=>'required',

       //     'TicketImage'=>'nullable',
       //     'cd_utc'=>'nullable',
       //     'picStatus'=>'nullable',
       //     'mobile_no' => 'required',
       //     'pp'=>'nullable',
       //     'Ddate'=>'nullable',
       //     'Dtime'=>'nullable',
       //     'ticket_no'=>'nullable',
       //     'ticketstatus'=>'nullable',
           
       //     'file'=>'nullable',
       //     'stut'=>'nullable',
       
       //  ]);




       //  $data = new TicketChats();



       //  $data->TicketTransactionId =$request->post('user_help');
       //  $data->playerId =$request->post('playerId');
        
      
       //  $data->desc =$request->post('desc');
       //  $data->TicketImage =$request->post('cd_utc');
       //  $data->cd_utc =$request->post('TicketTransactionId');
       //  $data->PicStatus =$request->post('picStatus');
       //  $data->mobile_no =$request->post('mobile_no');
       //  $data->pp =$request->post('pp');
       //  $data->date =$request->post('Ddate');
       //  $data->time =$request->post(' Dtime');
       //  $data->ticketno =$request->post('ticket_no');
       //  $data->ticket_status =$request->post('ticketstatus');
       //  $data->file =$request->post('file');
       //  $data->status =$request->post('stut');
        
       //  $data->save();
        

       // TicketChats::create($request->all());

       //  return ["result"=>"Data inserted"];

               // return json_encode(array(
               //     "statusCode"=>200
               // ));

         //   return response()->json(array(


         //           "statusCode"=>200

         //  ));

        // return json( $tickdata);


       // return response()->json($data);
}







            
}
