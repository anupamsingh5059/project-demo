<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Myapi extends Controller
{
    
       public function ApiData()
       {

         return ['name'=>'anupam', 'address'=>'Delhi'];

       }
      
}
