<?php

namespace App\Http\Controllers\admin;

// use App\Http\Controllers\Controller;
// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Hash;
// use Illuminate\Support\Facades\DB;
// use App\Models\admin\Tickets;
// use App\Models\admin\TicketChats;






use App\Models\admin\Tickets;
use App\Models\admin\TicketChats;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class TicketsController extends Controller
{

   public function Ticket()
   {


       //$userData = DB::collection('leader_board');

           $ticket = Tickets::all();
            

      // dd($ticket);
        return view('admin.ticket', compact('ticket'));



   }







            public function show($id)
            { 
                    $user = Tickets::find($id);

                    return response()->json($user);


                  //return redirect('admin.ticket')->json($user);
            }

            // public function TicketInsert($id)
            // {

            //         $user = Tickets::find($id);

            //         return response()->json($user);


            //       //return redirect('admin.ticket')->json($user);
            // }
     public function Chats_Data(Request $request){

           
        $request->validate([
             
          'desc'=>'required',
          'user_player'=>'required',
          'mobile_no'=>'required',



         
          

 ]);


         $model = new TicketChats();
         $model->desc = $request->get('desc');
         $model->TicketTransactionId = $request->get('user_player');
         $model->mobile_no = $request->get('mobile_no');
        
            $model->save();
           //dd($model);
           // return redirect('/')->with('message', 'Records  has been added successfully ');


            //         return response()->json(array(


            //           "statusCode"=>200

            //  ));


            return ["msg"=>"Data Inserted Into Database"];

          //  $dataUsermodel =  new  TicketChats();

          //  $dataUsermodel->desc =$request->post('desc');



          //  $dataUsermodel->save();

          //    return ["result"=>"Data inserted"];
     // $tickettt = TicketChats::all();

      //dd($tickettt);
                       
             //return   $request->post();
     // dd($request->all());
     

     
          //  $request->validate([

          //     'user_player' => 'required',
          //     'desc'=>'required',

          //     'TicketImage'=>'nullable',
          //     'cd_utc'=>'nullable',
          //     'picStatus'=>'nullable',
          //     'mobile_no' => 'required',
          //     'pp'=>'nullable',
          //     'Ddate'=>'nullable',
          //     'Dtime'=>'nullable',
          //     'ticket_no'=>'nullable',
          //     'ticketstatus'=>'nullable',
              
          //     'file'=>'nullable',
          //     'stut'=>'nullable',
          
          //  ]);




          //  $data = new TicketChats();



          //  $data->TicketTransactionId =$request->post('user_help');
          //  $data->playerId =$request->post('playerId');
           
         
          //  $data->desc =$request->post('desc');
          //  $data->TicketImage =$request->post('cd_utc');
          //  $data->cd_utc =$request->post('TicketTransactionId');
          //  $data->PicStatus =$request->post('picStatus');
          //  $data->mobile_no =$request->post('mobile_no');
          //  $data->pp =$request->post('pp');
          //  $data->date =$request->post('Ddate');
          //  $data->time =$request->post(' Dtime');
          //  $data->ticketno =$request->post('ticket_no');
          //  $data->ticket_status =$request->post('ticketstatus');
          //  $data->file =$request->post('file');
          //  $data->status =$request->post('stut');
           
          //  $data->save();
           

          // TicketChats::create($request->all());

          //  return ["result"=>"Data inserted"];

                  // return json_encode(array(
                  //     "statusCode"=>200
                  // ));

            //   return response()->json(array(


            //           "statusCode"=>200

            //  ));

           // return json( $tickdata);


          // return response()->json($data);
  }

    
}
