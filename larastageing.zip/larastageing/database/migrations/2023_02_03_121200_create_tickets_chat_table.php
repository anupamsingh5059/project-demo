<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTicketsChatTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tickets_chat', function (Blueprint $table) {
            $table->id();

            $table->TicketTransactionId();
            $table->playerId();
            $table->desc();
            $table->TicketImage();

            $table->cd_utc();
            $table->PicStatus();
            $table->mobile_no();
            $table->pp();
            $table->time();
            $table->ticketno();

            $table->ticket_status();
            $table->file();
            $table->status();

          



          
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tickets_chat');
    }
}
