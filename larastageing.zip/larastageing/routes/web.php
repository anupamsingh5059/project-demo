<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\BrandController;

use App\Http\Controllers\admin\GameUserController;











    

     Route::POST('/user_client', [GameUserController::class, 'Chats_Data']);
    Route::get('/', [GameUserController::class, 'Ticket']);
    Route::get('users/{id}', [GameUserController::class, 'show'])->name('users');
    
    
    
    
    
    Route::get('/users-data',  [GameUserController::class, 'index']);
    
    Route::get('users-data',  [GameUserController::class, 'player']);
    
    Route::get('/users-data',[GameUserController::class, "getData"]);






/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });



// Route::get('/ticketuser',  [TicketsController::class, 'ticketuser']);
// Route::get('/user',  [TicketsController::class, 'Ticket']);
// Route::get('/user/{id}',  [TicketsController::class, 'show'])->name('ticket');












Route::get('/conection', function(){

    try {
        $dbconnect =  DB::connection()->getMongoClient()->listDatabases();
        return "connected success";

        //$dbname = DB::connection()->getDatabaseName();
        //echo "Connected successfully to the database. Database name is :".$dbname;
    } catch (\Exception $e) {
        echo $e->getMessage();
    }

});