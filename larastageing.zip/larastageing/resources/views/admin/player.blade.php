@extends('admin.layouts')




@section('container')





<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->




                                <div class="card">
  <div class="card-header">Header</div>
  <div class="card-body"> <div class="table-responsive "  >
                                    <table class="display" id="" >
                                        <thead>
                                            <tr>
                                                <th> ID</th>
                                                <th> User Name</th>
                                                <th>Mobile </th>
                                                <th>Email</th>
                                                <th>Status</th>
                                                <th>Updated</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>


                                        <tbody>
                                            
                                    

                                        </tbody>
                                    </table>
                                </div>
                            
                            
                            </div>
 
        </div>
                               
                                <!-- END DATA TABLE-->
                            </div>
        </div>


  

            














@endsection