@extends('layouts.master')




@section('container')


<div class="container">
      <div class="header_wrap">
        <div class="num_rows">
		
				<div class="form-group"> 	<!--		Show Numbers Of Rows 		-->
			 		<select class  ="form-control" name="state" id="maxRows">
						 
						 
						 <option value="10">10</option>
						 <option value="15">15</option>
						 <option value="20">20</option>
						 <option value="50">50</option>
						 <option value="70">70</option>
						 <option value="100">100</option>
                         <option value="5000">Show ALL Rows</option>
                         
						</select>
			 		
			  	</div>
        </div>
        <div class="tb_search">
<input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.." class="form-control">
        </div>
      </div>
<table class="table table-striped table-class" id= "table-id">
  
	
                              <thead style="color:pink">
                                              <tr>
                                               
                                                <th> User Name</th>
                                                <th>Mobile </th>
                                                <th>Email</th>
                                                <th>Status</th>
                                                <th>Updated</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                 </thead>
<tbody>

       @foreach($dataUser as $data)
        <tr>   
              
             <td>{{$data->un}}</td>
             
             
             <td>{{$data->mobile_no}}</td>
             <td>{{$data->ue}}</td>
             <td><a href="" class="btn btn-primary">Status</a></td>
             <td>{{$data->cd}}</td>
             <td><a href="" class="btn btn-primary"> Show</a>
                <a href="" class="btn btn-info">Edit</a>
             </td>
             
              
        </tr>
        @endforeach
	
  
    <tbody>
</table>

<!--		Start Pagination -->
		<!-- <div class='pagination-footer'>
              <span class="pagination-details"></span>
                       <nav>
                        <ul class="pagination">
                        <a href="#">&laquo;</a>
                        <a href="#">1</a>
                            <a class="active" href="#">2</a>
                            <a href="#">3</a>
                            <a href="#">4</a>
                            <a href="#">5</a>
                            <a href="#">6</a> -->
                            <!-- <a href="#">&raquo;</a>
                        </ul>
                        </nav> --> 

                        <!-- <div class="pagination-btn"> -->
                             <!-- <a href="#">Previous</a>
                            
                            <a href="#" class="active">1</a>
                            <a href="#">2</a>
                            <a href="#">3</a>
                            <a href="#" >Next</a> -->
                            

                        
                        <!-- </div> -->

		<!-- </div> -->


                    <!-- <div class="pagination">
                   
                    </div> -->
      <!-- <div class="rows_count">Showing 11 to 20 of 91 entries</div> -->







      <div class='pagination-container'>
				<nav>
				  <ul class="pagination">
				   <!--	Here the JS Function Will Add the Rows -->
				  </ul>
				</nav>
			</div>
      <div class="rows_count">Showing 11 to 20 of 91 entries</div>













</div> <!-- 		End of Container -->



<!--  Developed By Yasser Mas -->









@endsection