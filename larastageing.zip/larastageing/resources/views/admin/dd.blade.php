@extends('layouts.master')




@section('container')





<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->




                     
                                    <table class="display" id="DataTable" >
                                        <thead>
                                            <tr>
                                                <th> ID</th>
                                                <th> User Name</th>
                                                <th>Mobile </th>
                                                <th>Email</th>
                                                <th>Status</th>
                                                <th>Updated</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                        </thead>
                                        
                                        </tbody>

                                        <tbody id="">


                                        </tbody>
                                    </table>
                                </div>
                            
                            
                            </div>
 
       


        



<script>

$('#DataTable').DataTable({
    processing: true,
    serverSide: true,
    order: [[ 0, "desc" ]],
    ajax: "{{ url('users-data') }}",
    columns: [
    { data: 'unique_id' },
    { data: 'un' },
    
    { data: 'ue' },
    { data: 'mobile_no' },
    { data: 'cd' },
    ]
    });
    
    
    </script>











@endsection