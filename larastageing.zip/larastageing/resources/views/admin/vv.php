@extends('layouts.master')

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>


@section('container')


<div class="container">
      <div class="header_wrap">
        <div class="num_rows">
		
				<div class="form-group"> 	<!--		Show Numbers Of Rows 		-->
			 		<select class="form-control" name="state" id="maxRows">
						 
						 
						 <option value="10">10</option>
						 <option value="15">15</option>
						 <option value="20">20</option>
						 <option value="50">50</option>
						 <option value="70">70</option>
						 <option value="100">100</option>
            <option value="5000">Show ALL Rows</option>
						</select>
			 		
			  	</div>
        </div>
        <div class="tb_search">
<input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.." class="form-control">
        </div>
      </div>
<table class="table table-striped table-class" id= "table-id">
  
	
<thead style="color:pink">
<tr>
    
    <th>Phone</th>
    <th>Tickets No.</th>
		<th>Subject</th>
		<th>Status</th>
    <th>Date & Time</th>
		<th>Chats </th>

 
		
	</tr>
  </thead>
<tbody>
       
    @foreach($ticket as $data)
    <tr>   
              
                            <td>{{$data->mobile_no}}</td>
                            <td>{{$data->help_id}}</td>
                            <td>{{$data->TicketDisputeId}}</td>
                            <td><a href="" class="btn btn-info">{{$data->status}}</a></td>
                            <td>{{$data->help_raised}}</td>
                            <td><a href="javascript:void(0)"
                            
                            
                            data-url="{{ url('/users', $data->_id) }}"  id="show-user"  class="btn btn-success" onclick="openForm()">Chat</a>
                            <!-- <td><button class="open-button" ></button> -->

                            
                                <div class="chat-popup" id="myForm">

                              
                                  <form action="#" class="form-container"  method="POST" id="frm">
                                              @csrf
                                  <input type="hidden" name="_token" id="csrf" value="{{Session::token()}}">
                                  <!-- <input type="hidden" class="form-control" id="name" placeholder="Enter Name" name="name">   -->
                                  <p><strong>ID:</strong> <span  id="user_help_id"></span></p>
                                  <p><strong>Mobile:</strong> <span  id="user_mobile_no"></span></p>
                                  <!-- <p   class="help_id"></p> -->
                                  
                                  <!-- <p  ></p> -->
                                  <input type="hidden" class="form-control" id="playerId" placeholder="Enter Name" name="playerId">
                                  
                                  
                                  <input type="hidden" class="form-control" id="TicketImage" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="cd_utc" placeholder="Enter Name" name="name"> 
                                  <input type="hidden" class="form-control" id="PicStatus" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="pp" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="date" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="time" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id=" ticketno" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="ticket_status" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="file" placeholder="Enter Name" name="name">
                                  <input type="hidden" class="form-control" id="status" placeholder="Enter Name" name="name">
                                  
                                  
                                  
                                  
                                    <label for="msg"><b>Message</b></label>
                                    <textarea placeholder="Type message.." name="msg"  id="desc"></textarea>

                                    <button type="submit" class="btn" id="frmsubmit">Send</button>
                                    <button type="button" class="btn cancel" onclick="closeForm()" >Close</button>
                                  </form>
                                </div>
                               </td>      
              
</tr>
 @endforeach
	
  
    <tbody>
</table>

<!--		Start Pagination -->
			<div class='pagination-container'>
				<nav>
				  <ul class="pagination">
				   <!--	Here the JS Function Will Add the Rows -->
				  </ul>
				</nav>
			</div>
      <div class="rows_count">Showing 11 to 20 of 91 entries</div>

</div> <!-- 		End of Container -->



<!--  Developed By Yasser Mas -->



<script type="text/javascript">
      
    $(document).ready(function () {
       
       /* When click show user */
        $('body').on('click', '#show-user', function () {
          var userURL = $(this).data('url');
              $.get(userURL, function (data) {
               
                  //console.log(data);

                $('#userShowModal').modal('show');
             
                 $('#user_help_id').text(data.help_id);
                 $('#user_mobile_no').text(data.mobile_no);
          })
       });


        



    //    $("form").submit(function (event) {


          
    //    //var  playerId = $('#user_help_id').text();


    //       // alert(playerId);
    //    var formData = {
    

            
        
    //     // TicketTransactionId: $('#TicketTransactionId').val(),
    //      playerId: $('#playerId').val(),
        
    //      userhelp: $('#user_help_id').text(),

    //      desc : $('#desc').val(),
    //       cd_utc: $('#cd_utc').val(),
    //      mobile_no: $('#user_mobile_no').text(),

    //    TicketImage:$('#TicketImage').val(),
    //    picStatus: $('#PicStatus').val(),
    //    pp : $('#pp').val(),
       

  
    //     Ddate: $('#date').val(),
    //     Dtime: $('#time').val(),
    //     ticket_no: $('#ticketno').val(),
    //     ticketstatus: $('#ticket_status').val(),

    //     file: $('#file').val(),
    //     stut: $('#status').val(),
        



    // };




    // var data = $('user_help_id').val();

    // alert(data);
  

      //  $.ajax({
      //     url:"{{ url('/user') }}",
      //     type: "POST",
        


      //       data: formData,
      //       dataType: "json",
         
      //      success: function(result){
      //        console.log(result);

           


              

              
              
      //     }


        
      // });
   
   
//  });



  // jQuery('#frm').submit(function(e){

  //      // e.frmsubmit();

  //      e.preventDefault();

  //     jQuery.ajax({

  //           url:"{{url('/userData')}}",
  //            data:jQuery('#frm').serialize(),
  //            type:"POST",
  //            success:function(result){

  //                 console.log(result);
  //            }
            
  //     });
  // }); 




       
// });
});  
</script>





@endsection