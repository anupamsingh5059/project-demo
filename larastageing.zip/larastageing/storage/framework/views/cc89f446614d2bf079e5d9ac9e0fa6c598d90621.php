




<?php $__env->startSection('container'); ?>


<div class="container">
      <div class="header_wrap">
        <div class="num_rows">
		
				
        </div>
        <div class="tb_search">
<input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.." class="form-control">
        </div>
      </div>
<table class="table table-striped table-class" id= "table-id">
  
	
                              <thead style="color:pink">
                                              <tr>
                                               
                                                <th> User Name</th>
                                                <th>Mobile </th>
                                                <th>Email</th>
                                                <th>Status</th>
                                                <th>Updated</th>
                                                <th>Action</th>
                                               
                                            </tr>
                                 </thead>
<tbody>

     <td><?php echo e($datashows->mobile_no); ?></td>
	
  
    <tbody>
</table>

<!--		Start Pagination -->
		<!-- <div class='pagination-footer'>
              <span class="pagination-details"></span>
                       <nav>
                        <ul class="pagination">
                        <a href="#">&laquo;</a>
                        <a href="#">1</a>
                            <a class="active" href="#">2</a>
                            <a href="#">3</a>
                            <a href="#">4</a>
                            <a href="#">5</a>
                            <a href="#">6</a> -->
                            <!-- <a href="#">&raquo;</a>
                        </ul>
                        </nav> --> 

                        <!-- <div class="pagination-btn"> -->
                             <!-- <a href="#">Previous</a>
                            
                            <a href="#" class="active">1</a>
                            <a href="#">2</a>
                            <a href="#">3</a>
                            <a href="#" >Next</a> -->
                            

                        
                        <!-- </div> -->

		<!-- </div> -->


                    <!-- <div class="pagination">
                   
                    </div> -->
      <!-- <div class="rows_count">Showing 11 to 20 of 91 entries</div> -->







     












</div> <!-- 		End of Container -->



<!--  Developed By Yasser Mas -->









<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastageing\resources\views/admin/show.blade.php ENDPATH**/ ?>